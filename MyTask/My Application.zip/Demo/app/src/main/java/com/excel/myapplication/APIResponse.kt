package com.excel.myapplication

import retrofit2.Call
import retrofit2.Callback
import retrofit2.http.GET
import retrofit2.http.POST


interface APIResponse {
    @GET("/alert/moduleAlerts?marine_id=0&alert_module_type=VesselsOperations&page=1")
    fun basicLogin(): Call<ResponseModel>?
}