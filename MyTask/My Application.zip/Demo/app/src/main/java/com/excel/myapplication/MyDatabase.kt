package com.excel.myapplication

import android.content.Context
import android.os.AsyncTask

import androidx.sqlite.db.SupportSQLiteDatabase

import androidx.room.Room

import androidx.room.RoomDatabase

import android.graphics.ColorSpace.Model

import androidx.room.Database


@Database(entities = [Model::class], version = 5)
abstract class MyDatabase : RoomDatabase() {
    abstract fun catimgDao(): catimgDao
    internal class PopulateDbAsyn(catDatabase: MyDatabase?) :
        AsyncTask<Void?, Void?, Void?>() {
        private val catimgDao: catimgDao
        init {
            catimgDao = catDatabase!!.catimgDao()
        }

        override fun doInBackground(vararg p0: Void?): Void? {
            catimgDao.deleteAll()
            return null
        }
    }

    companion object {
        private const val DATABASE_NAME = "Cat"

        @Volatile
        var INSTANCE: MyDatabase? = null
        fun getInstance(context: Context?): MyDatabase? {
            if (INSTANCE == null) {
                synchronized(MyDatabase::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = Room.databaseBuilder(
                            context!!,
                            MyDatabase::class.java, DATABASE_NAME
                        )
                            .fallbackToDestructiveMigration()
                            .addCallback(callback)
                            .build()
                    }
                }
            }
            return INSTANCE
        }

        var callback: Callback = object : Callback() {
            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                PopulateDbAsyn(INSTANCE)
            }
        }
    }
}