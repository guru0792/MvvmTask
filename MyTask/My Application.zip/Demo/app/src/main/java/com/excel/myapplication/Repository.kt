package com.excel.myapplication

import android.graphics.ColorSpace.Model

import android.os.AsyncTask

import androidx.lifecycle.LiveData

import android.app.Application


class Repository(application: Application?) {
    var catimgDao: catimgDao
    var allCats: LiveData<List<Model?>?>?
    private val database: MyDatabase
    fun insert(cats: List<Model?>?) {
        InsertAsyncTask(catimgDao).execute(cats)
    }

    private class InsertAsyncTask(private val catimgDao: catimgDao) :
        AsyncTask<List<Model?>?, Void?, Void?>() {
        override fun doInBackground(vararg lists: List<Model?>?): Void? {
            catimgDao.insert(lists[0])
            return null
        }
    }

    init {
        database = MyDatabase.getInstance(application)!!
        catimgDao = database.catimgDao()
        allCats = catimgDao.getcats()
    }
}