package com.excel.myapplication

data class DataRes (val alerts : List<ResponseModel>)