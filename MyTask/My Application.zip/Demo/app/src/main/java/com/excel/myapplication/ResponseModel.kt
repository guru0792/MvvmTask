package com.excel.myapplication



data class ResponseModel(val alert_message: String, val alert_location : String, val alert_priority: String, val alert_module_type: String)