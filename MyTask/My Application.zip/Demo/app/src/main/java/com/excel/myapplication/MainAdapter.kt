package com.excel.myapplication

import android.content.ClipData
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.excel.myapplication.databinding.AdapterMovieBinding
import android.content.ClipData.Item




open class MainAdapter: RecyclerView.Adapter<MainAdapter.MainViewHolder>() {

    var movies = mutableListOf<ResponseModel>()

    fun setMovieList(movies: List<ResponseModel>) {
        this.movies = movies.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val binding = AdapterMovieBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val movie = movies[position]
        holder.binding.name.text = movie.alert_message

    }

    override fun getItemCount(): Int {
        return movies.size
    }

//    open fun removeItem(position: Int) {
//        movies.removeAt(position)
//        notifyItemRemoved(position)
//    }



    class MainViewHolder(val binding: AdapterMovieBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}

