package com.excel.myapplication

import android.content.ClipData
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.excel.myapplication.databinding.ActivityMainBinding
import androidx.recyclerview.widget.ItemTouchHelper
import com.google.android.material.snackbar.Snackbar

import android.content.ClipData.Item
import android.graphics.Color
import android.view.View


class MainActivity : AppCompatActivity(){

    private val TAG = "MainActivity"
    private lateinit var binding: ActivityMainBinding

    lateinit var viewModel: MainViewModel

    private val retrofitService = RetrofitService.getInstance()
    val adapter = MainAdapter()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, MyViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)

        binding.recyclerview.adapter = adapter

        viewModel.movieList.observe(this, Observer {
            Log.d(TAG, "onCreate: $it")
            adapter.setMovieList(it.alerts)
        })

        viewModel.errorMessage.observe(this, Observer {

        })
        viewModel.getAllMovies()

//        val itemTouchHelperCallback: ItemTouchHelper.SimpleCallback =
//            RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this)
//        ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(binding.recyclerview)

    }

/*    override fun onSwiped(viewHolder: RecyclerView.ViewHolder?, direction: Int, position: Int) {
        if (viewHolder is MainAdapter.MainViewHolder) {
            // get the removed item name to display it in snack bar

            // remove the item from recycler view
            adapter.removeItem(viewHolder!!.adapterPosition)

            // showing snack bar with Undo option
            val snackbar = Snackbar
                .make(binding.coordinatorLayout, " removed from cart!", Snackbar.LENGTH_LONG)

            snackbar.setActionTextColor(Color.YELLOW)
            snackbar.show()
        }
    }*/


}