package com.excel.myapplication

import android.graphics.ColorSpace.Model

import androidx.lifecycle.LiveData

import androidx.room.OnConflictStrategy

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query


@Dao
interface catimgDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(cats: List<DataRes?>?)

    @Query("SELECT DISTINCT * FROM catimg")
    fun getcats(): LiveData<List<DataRes?>?>?

    @Query("DELETE FROM catimg")
    fun deleteAll()
}